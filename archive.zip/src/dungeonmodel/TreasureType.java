package dungeonmodel;

/**
 * Represent type of treasure.
 */
enum TreasureType {
  DIAMOND, SAPPHIRE, RUBY
}

